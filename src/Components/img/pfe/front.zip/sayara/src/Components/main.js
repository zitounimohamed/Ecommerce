import React from 'react';
import {Switch, Route, BrowserRouter} from 'react-router-dom';
import Inscription from './inscrit';


const Main= ()=>
(    <BrowserRouter>
    <Switch>
        <Route path="/inscrit" component={Inscription}/>
        
    </Switch></BrowserRouter>
)
export default Main;

